# Handoff: BodyForme Transactional & Lifecycle Email Templates

## Overview
A set of **6 styled email templates** for BodyForme Pilates studio, covering transactional, billing, and lifecycle/re-engagement touchpoints. Each email shares a common shell (italic wordmark header, body, CTA button, address footer) and a warm, editorial, graphic-light tone modeled on the studio's booking-confirmation email.

The templates are:
1. **Welcome** (post-checkout) — confirms an activated membership
2. **Payment failed** (billing) — prompts the member to fix a failed charge
3. **Review request** (engagement) — asks regular attendees for a Google review
4. **30-day winback** (re-engagement) — warm "we've missed you" nudge
5. **90-day check-in** (re-engagement) — gentle "still here" check-in
6. **Migration** (announcement) — asks Mind Body members to create an account in the new booking system

## About the Design Files
The files in this bundle are **design references created in HTML/React** — prototypes that show the intended look, copy, and structure. They are **not production-ready email HTML**. They render with modern CSS (flexbox, `border-radius`, web fonts via `<link>`) and React + Babel in the browser purely for previewing.

The task is to **recreate these designs as real, sendable emails** in the target environment. For email this almost always means **table-based, inline-styled HTML** for client compatibility (Outlook, Gmail, Apple Mail), typically authored via an email framework (e.g. **MJML**, **react-email**, **Maizzle**, or Handlebars/Liquid templates in your ESP). Use whichever the team already has; if none exists, **react-email** or **MJML** are good defaults.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, copy, and layout are all intended as shown. Recreate them faithfully. The only thing to substitute is the *rendering technology* (modern CSS → email-safe HTML/CSS) and dynamic values (see Merge Fields).

## Email Shell (shared by all 6)
Every template is composed of the same three regions inside a centered card.

- **Outer canvas**: full-width `#f4ede1` (linen) background, vertical padding ~56px top.
- **Email card**: `max-width: 600px`, centered, `background #fdfaf6` (canvas), `border: 1px solid #d8ccba`, `border-radius: 4px`. In a real email, drop the box-shadow (poor client support) or keep it as a progressive enhancement.
- **Header**: padding `34px 48px 28px`, bottom border `1px solid #d8ccba`. Contains the wordmark **"Bodyforme"** — Cormorant Garamond, *italic*, weight 500, `30px`, color `#2a1506`.
- **Body**: padding `44px 48px 40px`. Left-aligned. Structure per template below.
- **Footer**: padding `28px 48px 36px`, top border `1px solid #d8ccba`.
  - Studio line: `12px`, `#a08568`, with `BodyForme Pilates` bolded in `#2a1506` — full text: **"BodyForme Pilates — 132 Ayr Street, Doncaster VIC 3108"**
  - Links row (gap 18px): "Timetable", "My Account", "Contact" — `11px`, uppercase, letter-spacing `0.08em`, color `#7a4a2a`.
  - Legal line: `11px`, `#a08568`, with "Manage preferences" + "Unsubscribe" underlined links.

### Body element styles (shared)
- **Eyebrow**: `11px`, uppercase, letter-spacing `0.18em`, color `#7a4a2a` (brown), margin-bottom 18px.
- **Heading** (`h1`): Cormorant Garamond, weight 500, `38px`, line-height `1.12`, color `#2a1506`. `<em>` inside = italic (same color). Margin-bottom 24px.
- **Body paragraph**: DM Sans, `15px`, line-height `1.72`, color `#2a1506`, margin-bottom 18px. `<strong>` = weight 600.
- **Muted paragraph** (`p.muted`): `14px`, color `#a08568`.
- **Inline link** (`a.inline`): color `#7a4a2a`, underlined, underline-offset 2px.
- **CTA button**: `display:inline-block`, background `#2a1506`, color `#f4ede1`, DM Sans `11px` weight 500, uppercase, letter-spacing `0.14em`, padding `15px 34px`, border-radius `2px`, margin `12px 0 8px`. (In email HTML, build this as a bulletproof button — a `<table>`/`<a>` with padding, not a `<button>`.)
- **Detail box** (`.detail-box`): background `#f4ede1`, border `1px solid #d8ccba`, border-radius 3px, padding `20px 24px`, margin `6px 0 26px`. Contains rows.
  - **Detail row**: flex space-between, baseline-aligned, padding `7px 0`, divider `1px solid #d8ccba` between rows.
    - key (`.k`): `12px`, uppercase, letter-spacing `0.08em`, color `#a08568`.
    - value (`.v`): `14px`, weight 500, color `#2a1506`.
- **Sign-off** (`.signoff`): margin-top 28px, `15px`, line-height 1.7. The name line is Cormorant italic `20px`.
- **Horizontal rule** (`.rule`): 1px `#d8ccba`, margin `32px 0`.

## Per-Template Content

### 1. Welcome (post-checkout · transactional)
- Subject: **"Your membership is active"**
- Eyebrow: "Welcome to the studio" · Heading: "You're *in*."
- Greeting "Hi Sarah," → paragraph confirming **Unlimited Monthly** is active.
- Detail box: Plan = Unlimited Monthly · Billing = $189 / month · Status = Active.
- Paragraph suggesting Reformer Foundations / Warm Flow for newcomers, arrive 10 min early.
- **CTA: Browse timetable**
- Sign-off: "See you on the mat, — The BodyForme team"

### 2. Payment failed (billing · transactional)
- Subject: **"A problem with your payment"**
- Eyebrow: "Action needed" · Heading: "A small hiccup with your *payment*"
- Paragraph: trouble processing payment for **Unlimited Monthly**; reassuring (expired card / bank decline).
- Detail box: Plan = Unlimited Monthly · Amount due = $189.00 · Next attempt = In 3 days.
- Paragraph: update details to avoid interruption; auto-retry once updated.
- **CTA: Update payment details**
- Muted closer: reply if already fixed / think it's a mistake.

### 3. Review request (lifecycle · engagement)
- Subject: **"Would you mind leaving a review?"**
- Eyebrow: "A small favour" · Heading: "How's your *practice* going?"
- Paragraphs: noticed regular attendance; if BodyForme's been good, would they leave a quick review — helps others find the studio.
- **CTA: Leave a review on Google**
- Rule, then muted: takes ~a minute, means the world to a small studio.
- Sign-off: "With gratitude, — The BodyForme team"

### 4. 30-day winback (lifecycle · re-engagement)
- Subject: **"We've missed you"**
- Eyebrow: "It's been a little while" · Heading: "We've *missed* you"
- Paragraphs: ~a month since last class; no pressure; heat's on, spot's waiting; one gentle class is enough.
- **CTA: Browse the schedule**
- Sign-off: "Hope to see you soon, — The BodyForme team"

### 5. 90-day check-in (lifecycle · re-engagement)
- Subject: **"Just checking in"**
- Eyebrow: "A gentle check-in" · Heading: "Still *here* whenever you are"
- Paragraphs: few months since last seen; membership **still active**; no wrong time to return.
- **CTA: Book a class**
- Rule, then muted: happy to pause/adjust plan — reply to email (inline link).
- Sign-off: "Warmly, — The BodyForme team"

### 6. Migration (announcement · Mind Body members)
- Subject: **"Action needed: new booking system"**
- Eyebrow: "Something new" · Heading: "We've moved to a new *booking system*"
- Paragraphs: upgraded system, faster/simpler; must **create a new account**; membership + credits carry over.
- Detail box: Step 1 = Create your account · Step 2 = Confirm your details · Step 3 = Book as usual.
- **CTA: Create account**
- Muted closer: use the same email as Mind Body to auto-link; reply for help.

## Merge Fields (dynamic values)
Replace the hardcoded preview values with the ESP's merge syntax:
- `Sarah` → first name (`[First name]`)
- `Unlimited Monthly` → `[Plan Name]`
- `$189 / month`, `$189.00` → `[Plan Price]` / `[Amount Due]`
- `In 3 days` → `[Next Retry Date]`
- All CTA `href="#"` → real destination URLs (timetable, billing portal, Google review link, account creation, etc.)
- Footer "Manage preferences" / "Unsubscribe" → ESP-generated links (legally required for non-transactional sends).

## Design Tokens
| Token | Value | Usage |
|---|---|---|
| Linen | `#f4ede1` | Page background, detail-box bg, CTA text |
| Canvas | `#fdfaf6` | Email card background |
| Espresso | `#2a1506` | Headings, body text, CTA background |
| Muted | `#a08568` | Secondary/muted text, footer |
| Brown | `#7a4a2a` | Eyebrows, links, accents |
| Divider | `#d8ccba` | All borders / rules |
| Radius (card) | `4px` | Email card |
| Radius (box/button) | `3px` / `2px` | Detail box / CTA |
| Body font | `'DM Sans', system-ui, sans-serif` | All body, eyebrow, CTA, footer |
| Display font | `'Cormorant Garamond', Georgia, serif` | Wordmark, headings, sign-off name (italic accent) |
| Card width | `600px` max | Standard email width |

### Type scale
- Wordmark: Cormorant italic 500, 30px
- Heading: Cormorant 500, 38px / 1.12
- Sign-off name: Cormorant italic, 20px
- Body: DM Sans 15px / 1.72
- Muted body: DM Sans 14px
- Eyebrow / detail key: 11–12px uppercase, letter-spacing 0.08–0.18em
- CTA / footer links: 11px uppercase, letter-spacing 0.08–0.14em

## Email-Build Notes
- **Fonts**: web fonts (`Cormorant Garamond`, `DM Sans`) only render in some clients (Apple Mail, iOS). Provide fallbacks — serif fallback `Georgia, serif` for Cormorant, `system-ui, Arial, sans-serif` for DM Sans — so Outlook/Gmail degrade gracefully.
- **Layout**: convert the flex header/footer/detail rows to `<table>` layouts with inline styles. The detail-row space-between becomes a 2-cell table row (left-aligned key, right-aligned value).
- **CTA**: build a bulletproof button (padded `<a>` inside a `<table>` cell) rather than relying on `display:inline-block` padding alone.
- **Shadows/border-radius**: keep as progressive enhancement; ensure the design still reads with square corners and no shadow.
- **Width**: lock the card to 600px with a wrapper table; many clients ignore `max-width`.
- **Dark mode**: consider `@media (prefers-color-scheme: dark)` overrides — the warm palette can invert poorly.

## Files
- `emails.html` — preview shell: shared header/footer, tab switcher, and all shared CSS (the source of truth for tokens & component styles).
- `emails.jsx` — the 6 template bodies, one object per email (`tab`, `label`, `subject`, `render()`).

A developer can read `emails.html` for the exact CSS values and `emails.jsx` for the exact copy and per-template structure.
