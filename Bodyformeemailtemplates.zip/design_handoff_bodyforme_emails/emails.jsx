// All 6 BodyForme email templates. Each entry: tab, label, subject, render().
// render() returns the email BODY (header + footer are supplied by the shell).

window.EMAILS = [

  /* ───────────────────────── 1. WELCOME ───────────────────────── */
  {
    tab: "Welcome",
    label: "Post-checkout · Transactional",
    subject: "Your membership is active",
    render: () => (
      <React.Fragment>
        <div className="email-eyebrow">Welcome to the studio</div>
        <h1 className="email-heading">You're <em>in</em>.</h1>
        <p>Hi Sarah,</p>
        <p>
          Your <strong>Unlimited Monthly</strong> is now active — which means the mat,
          the heat and the whole timetable are yours. The hardest part is over; now
          all that's left is to show up.
        </p>
        <div className="detail-box">
          <div className="detail-row">
            <span className="k">Plan</span>
            <span className="v">Unlimited Monthly</span>
          </div>
          <div className="detail-row">
            <span className="k">Billing</span>
            <span className="v">$189 / month</span>
          </div>
          <div className="detail-row">
            <span className="k">Status</span>
            <span className="v">Active</span>
          </div>
        </div>
        <p>
          New here? We'd suggest starting with a <strong>Reformer Foundations</strong> or
          a <strong>Warm Flow</strong> class to find your feet. Arrive ten minutes early
          and we'll take care of the rest.
        </p>
        <a href="#" className="cta">Browse timetable</a>
        <div className="signoff">
          See you on the mat,<br />
          <span className="name">The BodyForme team</span>
        </div>
      </React.Fragment>
    ),
  },

  /* ──────────────────────── 2. PAYMENT FAILED ─────────────────── */
  {
    tab: "Payment failed",
    label: "Billing · Transactional",
    subject: "A problem with your payment",
    render: () => (
      <React.Fragment>
        <div className="email-eyebrow">Action needed</div>
        <h1 className="email-heading">A small hiccup<br />with your <em>payment</em></h1>
        <p>Hi Sarah,</p>
        <p>
          We had trouble processing your payment for your{" "}
          <strong>Unlimited Monthly</strong> membership. It happens — often it's just
          an expired card or a bank declining an automatic charge.
        </p>
        <div className="detail-box">
          <div className="detail-row">
            <span className="k">Plan</span>
            <span className="v">Unlimited Monthly</span>
          </div>
          <div className="detail-row">
            <span className="k">Amount due</span>
            <span className="v">$189.00</span>
          </div>
          <div className="detail-row">
            <span className="k">Next attempt</span>
            <span className="v">In 3 days</span>
          </div>
        </div>
        <p>
          To keep your bookings running without interruption, please take a moment to
          update your payment details. We'll retry automatically once they're in.
        </p>
        <a href="#" className="cta">Update payment details</a>
        <p className="muted" style={{ marginTop: "22px" }}>
          Already sorted it, or think this is a mistake? Just reply to this email and
          we'll help you out.
        </p>
      </React.Fragment>
    ),
  },

  /* ──────────────────────── 3. REVIEW REQUEST ─────────────────── */
  {
    tab: "Review",
    label: "Lifecycle · Engagement",
    subject: "Would you mind leaving a review?",
    render: () => (
      <React.Fragment>
        <div className="email-eyebrow">A small favour</div>
        <h1 className="email-heading">How's your <em>practice</em> going?</h1>
        <p>Hi Sarah,</p>
        <p>
          We've noticed you've been coming in regularly lately — and honestly, it's
          made our week. There's nothing we love more than seeing someone settle into
          a rhythm.
        </p>
        <p>
          If BodyForme has been good to you, would you mind leaving a quick review?
          A couple of honest sentences goes a long way in helping other people find
          their way to the mat.
        </p>
        <a href="#" className="cta">Leave a review on Google</a>
        <hr className="rule" />
        <p className="muted">
          It takes about a minute, and it means the world to a small studio like ours.
          Thank you for being part of it.
        </p>
        <div className="signoff">
          With gratitude,<br />
          <span className="name">The BodyForme team</span>
        </div>
      </React.Fragment>
    ),
  },

  /* ─────────────────── 4. RE-ENGAGEMENT · 30 DAYS ─────────────── */
  {
    tab: "30-day winback",
    label: "Lifecycle · Re-engagement",
    subject: "We've missed you",
    render: () => (
      <React.Fragment>
        <div className="email-eyebrow">It's been a little while</div>
        <h1 className="email-heading">We've <em>missed</em> you</h1>
        <p>Hi Sarah,</p>
        <p>
          It's been about a month since your last class, and the studio's just a touch
          quieter without you. No pressure at all — life gets full, and the mat will
          always be here when you're ready to come back to it.
        </p>
        <p>
          Whenever you feel like easing back in, the heat is on and your spot is
          waiting. Even one slow, gentle class can be enough to find your way again.
        </p>
        <a href="#" className="cta">Browse the schedule</a>
        <div className="signoff">
          Hope to see you soon,<br />
          <span className="name">The BodyForme team</span>
        </div>
      </React.Fragment>
    ),
  },

  /* ─────────────────── 5. RE-ENGAGEMENT · 90 DAYS ─────────────── */
  {
    tab: "90-day check-in",
    label: "Lifecycle · Re-engagement",
    subject: "Just checking in",
    render: () => (
      <React.Fragment>
        <div className="email-eyebrow">A gentle check-in</div>
        <h1 className="email-heading">Still <em>here</em><br />whenever you are</h1>
        <p>Hi Sarah,</p>
        <p>
          It's been a few months since we last saw you, so we wanted to check in — no
          agenda, just a friendly hello.
        </p>
        <p>
          Your membership is <strong>still active</strong> and ready whenever you'd
          like to use it. Whether it's been a busy season, an injury, or simply life
          getting in the way, there's no wrong time to come back.
        </p>
        <a href="#" className="cta">Book a class</a>
        <hr className="rule" />
        <p className="muted">
          And if your needs have changed, we're happy to talk through pausing or
          adjusting your plan — just <a className="inline" href="#">reply to this email</a>.
        </p>
        <div className="signoff">
          Warmly,<br />
          <span className="name">The BodyForme team</span>
        </div>
      </React.Fragment>
    ),
  },

  /* ─────────────────────── 6. MIGRATION ───────────────────────── */
  {
    tab: "Migration",
    label: "Announcement · Mind Body members",
    subject: "Action needed: new booking system",
    render: () => (
      <React.Fragment>
        <div className="email-eyebrow">Something new</div>
        <h1 className="email-heading">We've moved to a<br />new <em>booking system</em></h1>
        <p>Hi Sarah,</p>
        <p>
          We've upgraded to a brand-new booking system — faster, simpler, and far
          easier to use from your phone. It's a big step up from what you're used to
          with Mind Body.
        </p>
        <p>
          To keep booking your classes, you'll need to{" "}
          <strong>create a new account</strong>. It only takes a minute, and your
          membership and remaining credits carry over automatically.
        </p>
        <div className="detail-box">
          <div className="detail-row">
            <span className="k">Step 1</span>
            <span className="v">Create your account</span>
          </div>
          <div className="detail-row">
            <span className="k">Step 2</span>
            <span className="v">Confirm your details</span>
          </div>
          <div className="detail-row">
            <span className="k">Step 3</span>
            <span className="v">Book as usual</span>
          </div>
        </div>
        <a href="#" className="cta">Create account</a>
        <p className="muted" style={{ marginTop: "22px" }}>
          Use the same email address you booked with on Mind Body and everything will
          link up for you. Need a hand? Just reply — we're happy to walk you through it.
        </p>
      </React.Fragment>
    ),
  },

];
