# Handoff: Bodyforme — Classes Schedule UI

## Overview
This is the main **Classes** view for the Bodyforme fitness studio management platform. It is a weekly schedule dashboard showing class sessions, sign-in counts, instructors, and summary statistics. It mirrors the structure of a MindBody-style booking system but with a refined, warm luxury aesthetic.

## About the Design Files
The files in this bundle are **design references created in HTML** — high-fidelity prototypes showing the intended look, layout, and interactions. They are **not** production code to copy directly. The task is to **recreate these designs in your target codebase** (React, Next.js, Vue, etc.) using its established patterns, component libraries, and routing conventions.

Open `Bodyforme.html` in any browser to see the full interactive reference.

## Fidelity
**High-fidelity.** This is a pixel-precise mockup with final colors, typography, spacing, icons, and hover states. Recreate the UI pixel-accurately using your codebase's existing libraries and patterns.

---

## Screens / Views

### 1. Classes — Weekly Schedule View

**Purpose:** Studio staff view all classes scheduled for the current week, see sign-in numbers, assign or edit instructors, and navigate between Day / Week / Month views.

---

## Layout

### Shell
- **Full viewport** (`100vw × 100vh`), no scroll on the shell
- Two-column layout: `sidebar (220px fixed) + main (flex: 1)`
- Main column: vertical flex — `topbar (52px) → content (flex: 1, overflow hidden)`
- Content: vertical flex — `cal-toolbar → schedule (overflow-y: auto) → page-footer`

### Sidebar — `220px wide`
- Background: `#1e110a` (espresso) with subtle radial gradient overlays
- Before pseudo-element: two radial gradients for depth (top-left warm glow, bottom-right dark)
- **Logo area** (`padding: 18px 20px 16px`, border-bottom `rgba(255,255,255,0.06)`)
  - 30×30px rounded square logo mark (`border-radius: 8px`, bg `#b8674a` terracotta)
  - Wordmark: Cormorant Garamond 17px/600, color `#faf6ef`, accent word in `#d4896e`
- **Nav items** (`padding: 9px 20px`, font 12.5px Plus Jakarta Sans)
  - Default: color `oklch(0.85 0.02 60)`, transparent bg
  - Hover: color `#faf6ef`, bg `rgba(255,255,255,0.05)`
  - Active: color `#faf6ef`, bg `rgba(255,255,255,0.08)`, 3px left border `#b8674a`, font-weight 500
  - Icons: 15×15px SVG, opacity 0.75 (1.0 when active)
  - Expandable items show a `›` chevron right-aligned at opacity 0.4
- **Footer** (`padding: 14px 20px`, border-top `rgba(255,255,255,0.06)`)
  - Animated green pulse dot (8×8px, `#7a9482`, pulsing box-shadow)
  - "AI Assistant" label, 12px, `oklch(0.82 0.02 60)`

### Top Bar — `52px tall`
- Background: `oklch(0.99 0.005 80)` (near-white warm)
- Border-bottom: `1px solid #e0d5c8`
- Left: hamburger button (34×34px, border `#e0d5c8`, bg white, border-radius 8px)
- Center: search input (max-width 340px, height 34px, border-radius 8px, left icon)
  - Focus ring: `box-shadow: 0 0 0 3px oklch(0.65 0.12 30 / 0.12)`, border `#b8674a`
- Right: icon buttons (34×34px each) — History, Tasks, Reports, Help, Notifications (with badge), Avatar
  - Badge: 15×15px circle, bg `#b8674a`, white text 9px/600, border 2px white
  - Avatar: 32×32px circle, bg `#3a2318`, color `#faf6ef`, 11px/600

### Calendar Toolbar — `padding: 12px 24px`
- Background: `#faf6ef` (cream)
- Border-bottom: `1px solid #e0d5c8`
- Flex row, `gap: 10px`, items vertically centered
- **Date chip**: border `#e0d5c8`, bg white, height 32px, border-radius 8px, 12.5px text, calendar icon left
- **Today button**: height 32px, bg `#b8674a`, white, border-radius 8px, 12.5px/500, hover `#c97a5e`
- **Nav arrows**: 26×26px, border `#e0d5c8`, bg white, border-radius 6px
- **View tabs**: grouped (Day | Week | Month), border `#e0d5c8`, border-radius 8px, height 32px
  - Active tab: bg `#1e110a` (espresso), color `#faf6ef`, font-weight 500
  - Tabs share internal border-right dividers
- **Filter dropdowns** (right-aligned): height 32px, border `#e0d5c8`, bg white, border-radius 8px, chevron icon

---

## Schedule List

### Day Block
Each day is a `<section>` with:
- **Day header** (sticky, `top: 0`, z-index 5)
  - Grid: `180px | 1fr | 240px | 180px | 80px`
  - Background: `#f0e9de` (linen) — TODAY variant uses `oklch(0.96 0.015 40)` (warm peach)
  - Border-bottom `#e0d5c8`
  - Col 1: Day name (13px/600) + date + sign-in badge (`border-radius 20px`, bg `#f3ede3`)
  - TODAY badge: inline pill, bg `#b8674a`, white, 10px/600, `border-radius 10px`
  - Cols 2–4: uppercase labels, 10.5px/600, color `#9c7d6a`, letter-spacing 0.06em

### Class Row
- Same 5-col grid as header
- `padding: 10px 24px`
- Border-bottom: `oklch(0.9 0.01 80 / 0.6)` (soft)
- Hover: `oklch(0.97 0.008 70)` (warm tint)
- **Time col**: 12px, color `#6b5344`
- **Sign-in col**: 12px, count in bold `#1e110a`
- **Class name col**: flex row with 20×20px icon chip + linked class name
  - Icon chip colors by type:
    - Yoga: `oklch(0.9 0.06 145)` green
    - Pilates: `oklch(0.9 0.06 260)` blue
    - Hot/Bikram: `oklch(0.9 0.06 30)` orange
    - Strength: `oklch(0.9 0.06 200)` teal
  - Link: 12.5px/500, color `#b8674a`, underline on hover
- **Teacher col**: 15×15px checkbox + name (12.5px) + tag pill
  - Checkbox: border `#e0d5c8`, border-radius 4px; checked: bg `#b8674a`
- **Actions col**: `⋯` menu button (24×24px, border-radius 6px, hover bg `#f3ede3`)

### Stats Footer
- `padding: 20px 24px`, border-top `#e0d5c8`
- 3 stat lines (12px, color `#6b5344`), strong values in `#1e110a`
- Weekly average line: 13px/600, separated by border-top

### Page Footer
- `padding: 12px 24px`, bg `oklch(0.97 0.005 80)`, border-top `#e0d5c8`
- Three-column: brand wordmark | links | site ID

---

## Interactions & Behavior

| Interaction | Behavior |
|---|---|
| Nav item click | Highlight active state (left accent bar + bg tint) |
| Class row hover | Warm background tint `oklch(0.97 0.008 70)` |
| Class name click | Open class detail panel/modal |
| Teacher checkbox | Toggle checked → enable inline edit mode for teacher |
| ⋯ button | Open context menu (Edit, Cancel, Duplicate) |
| Today button | Jump calendar to current week/day |
| Day/Week/Month tabs | Switch schedule view |
| ‹ › arrows | Navigate previous/next period |
| Filter dropdowns | Filter by class type or instructor |
| Search input | Find client by name |
| Notification bell | Open notifications drawer |
| Avatar | Open user profile/account menu |
| AI Assistant | Open AI chat panel |

### Animations
- Day blocks fade + slide in on load: `opacity 0→1, translateY 6px→0`, staggered by 50ms per block
- AI dot: `opacity` pulse animation, 2s ease-in-out infinite
- All hover transitions: `0.12s–0.15s ease`

---

## State Management

```
- currentView: 'day' | 'week' | 'month'
- currentDate: Date (default: today)
- selectedClassTypes: string[] (empty = all)
- selectedInstructors: string[] (empty = all)
- editingTeacher: classId | null
- searchQuery: string
- notificationsOpen: boolean
- aiPanelOpen: boolean
```

---

## Design Tokens

### Colors
```css
--espresso:    #1e110a   /* Sidebar background */
--espresso-2:  #2c1a10   /* Sidebar hover */
--espresso-3:  #3a2318   /* Avatar bg */
--cream:       #faf6ef   /* Main background */
--cream-2:     #f3ede3   /* Hover tints, tag pills */
--cream-3:     #e8dfd2   /* Deeper cream */
--linen:       #f0e9de   /* Day header background */
--terracotta:  #b8674a   /* Primary accent — buttons, active, links */
--terra-light: #d4896e   /* Logo accent, lighter terracotta */
--terra-muted: #c97a5e   /* Button hover */
--sage:        #7a9482   /* AI dot */
--text-dark:   #1e110a   /* Primary text */
--text-mid:    #6b5344   /* Secondary text */
--text-light:  #9c7d6a   /* Tertiary / labels */
--border:      #e0d5c8   /* All borders */
```

### Typography
```
Display / Wordmark: Cormorant Garamond (Google Fonts)
  - Logo: 17px / weight 600

Body / UI: Plus Jakarta Sans (Google Fonts)
  - XS label:   10.5px / weight 600 / letter-spacing 0.06em (uppercase)
  - Small:       11–12px / weight 400
  - Body:        12.5px / weight 400–500
  - Subheading:  13px / weight 500–600
```

### Spacing
```
Sidebar width:   220px
Topbar height:    52px
Content padding:  24px horizontal
Row padding:      10px 24px
Cal toolbar:      12px 24px
```

### Border Radius
```
Buttons / chips:  8px
Small buttons:    6px
Logo mark:        8px
Badges:           50% (circle) / 20px (pill)
Checkboxes:       4px
```

### Shadows
```
Search focus: 0 0 0 3px oklch(0.65 0.12 30 / 0.12)
```

---

## Navigation Items (Sidebar)
In order:
1. Dashboard
2. **Classes** ← active view
3. Courses
4. Rooms
5. Check In
6. — divider —
7. Clients
8. Point of Sale
9. Insights ›
10. Marketing ›
11. Services & Products ›
12. Staff
13. Settings

---

## Data Structure (Classes)

```ts
type ClassSession = {
  id: string
  time: string          // e.g. "7:00 – 8:00 am"
  signedIn: number
  capacity: number
  className: string
  classType: 'yoga' | 'pilates' | 'hot' | 'strength'
  teacher: string
  editMode: boolean
}

type DaySchedule = {
  date: Date
  isToday: boolean
  signedInCount: number
  signedInPercent: number
  sessions: ClassSession[]
}
```

---

## Assets
- All icons are inline SVGs (no external icon library required)
- Google Fonts: `Cormorant+Garamond:wght@400;500;600` and `Plus+Jakarta+Sans:wght@300;400;500;600`
- No images used — purely typographic and color-based design

## Files in This Package
| File | Description |
|---|---|
| `Bodyforme.html` | Full hi-fi prototype — open in browser to preview |
| `README.md` | This document |
